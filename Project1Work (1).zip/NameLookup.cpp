#include "NameLookup.h"
NameSearch::NameSearch(string marvel)
{
  
  Character nameData;
  ifstream infile("marvel-wikia-data.csv");
  if(infile.good())
  {
    while(1)
    {
      infile>>nameData.page_id;
      infile>>nameData.name;
      infile>>nameData.urlslug;
      infile>>nameData.ident;
      infile>>nameData.align;
      infile>>nameData.eye;
      infile>>nameData.hair;
      infile>>nameData.sex;
      infile>>nameData.GSM;
      infile>>nameData.alive;
      infile>>nameData.appearance;
      infile>>nameData.first_app;
      infile>>nameData.year;

      nameMap[nameData.name]=nameData;

    }
    infile.close();
    success=true;
  }else 
  {
    success=false;
  }
}

bool NameSearch::NameSearchSuccess()
{
  return success;
}

vector<Character> NameSearch::getMatches(string name)
{
  vector<Character> matchList;
  Character match;
  map<string, Character>::iterator it=nameMap.lower_bound(name);

return matchList;
}

