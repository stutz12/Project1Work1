#include <iostream>
#include <algorithm>
#include <sys/stat.h>
#include <fstream>
#include <map>
#include "NameEntry.h"
#include "NameLookup.h"
using namespace std;
int main() 
{
  NameSearch nameMap("marvel-wikia-data.csv");
  if(!nameMap.NameSearchSuccess())
  {
    cout<<"File Open Failure!!!!!!!!"<<endl;
    return 1;
  }
vector<Character> matchList;
string x;
cin>>x;
transform(x.begin(), x.end(), x.begin(), ::toupper);
matchList= nameMap.getMatches(x);
for(int i=0; i<matchList.size(); i++)
{
  cout<<matchList.at(i).name<<endl;
}


return 0;
}