#include <iostream>
#include <fstream>
#include <map>
#include <vector>
#include <string>
#ifndef NAMEENTRY_H
#define NAMEENTRY_H
using namespace std;
class Character
{
  public:
  Character();
  string page_id;
  string name;
  string urlslug;
  string ident;
  string align;
  string eye;
  string hair;
  string sex;
  string GSM;
  string alive;
  string appearance;
  string first_app;
  string year;

};
#endif //NAMEENTRY_H