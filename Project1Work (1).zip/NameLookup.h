#include <iostream>
#include <fstream>
#include <map>
#include <vector>
#include <string>
#include <sys/stat.h>
#include <algorithm>
#include "NameEntry.h"
using namespace std;
class NameSearch
{
  public:
  NameSearch(string marvel);
  bool NameSearchSuccess();
  vector<Character> getMatches(string marvel);
  private:
  map<string, Character> nameMap;
  bool success;
};