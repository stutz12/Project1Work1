#include "NameEntry.h"

Character::Character()
{
  page_id="";
   name="";
   urlslug="";
   ident="";
   align="";
   eye="";
   hair="";
   sex="";
   GSM="";
   alive="";
   appearance="";
   first_app="";
   year="";
}